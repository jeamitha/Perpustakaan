/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package perpustakaan;

import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author KAHFI
 */
public class Buku {
    private String judul,penerbit;
    private int harga, kode_buku;

    public Buku(int kode_buku, String judul, String penerbit, int harga) {
        this.kode_buku = kode_buku;
        this.judul = judul;
        this.penerbit = penerbit;
        //this.jumlah = jumlah;
        this.harga = harga;
    }

    public Buku() {
    }

    public int getKode_buku() {
        return kode_buku;
    }

    public String getJudul() {
        return judul;
    }

    public String getPenerbit() {
        return penerbit;
    }

//    public int getJumlah() {
//        return jumlah;
//    }

    public int getHarga() {
        return harga;
    }

    public void setKode_buku(int kode_buku) {
        this.kode_buku = kode_buku;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public void setPenerbit(String penerbit) {
        this.penerbit = penerbit;
    }

//    public void setJumlah(int jumlah) {
//        this.jumlah = jumlah;
//    }

    public void setHarga(int harga) {
        this.harga = harga;
    }
    public void insert(String judul, String penerbit, int harga){
        Database db = new Database();
        db.setData("insert into buku (Judul,Penerbit,Harga,Status) values('"+judul+"','"+penerbit+"','"+harga+"','Available');");
    }
    public void delete(String id){
        Database db = new Database();
        db.setData("delete from buku where Kode='"+id+"';");
    }
    public void update(int Kode, String judul, String penerbit,  int harga){
        Database db = new Database();
        db.setData("update buku set Judul='"+judul+"',Penerbit='"+penerbit+"',Harga="+harga+" where Kode="+Kode+";");
    }
    public ResultSet search(String kode){
        ResultSet rs=null;
        Database db= new Database();
        try {
            rs=db.getData("select * from buku where Kode='"+kode+"';");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return rs;
    }
    public void pinjam(String id){
        Database db = new Database();
        ResultSet rs=null;
        String stat="";
        try {
            rs=db.getData("select * from buku where Kode='"+id+"';");
            while(rs.next()){
                stat=rs.getString("Status");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        if("Available".equals(stat)){
            stat="Out Of Stock";
            db.setData("update buku set Status='"+stat+"' where Kode='"+id+"';");
        }
    }
    public void kembali(String id){
        Database db = new Database();
        ResultSet rs=null;
        String stat="";
        try {
            rs=db.getData("select * from buku where Kode='"+id+"';");
            while(rs.next()){
                stat=rs.getString("Status");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        if("Out Of Stock".equals(stat)){
            stat="Available";
            db.setData("update buku set Status='"+stat+"' where Kode='"+id+"';");
        }
    }
}
